@echo off
reg delete "HKCU\Software\Microsoft\Office\Excel\Addins\AutomationDesigner" /f
rmdir /S /Q "%LOCALAPPDATA%\AutomationDesigner"
echo Uninstalled.
pause
