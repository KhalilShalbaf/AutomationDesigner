@echo off
set "SRC=%~dp0"
set "SRC=%SRC:~0,-1%"
set "DST=%LOCALAPPDATA%\AutomationDesigner"
echo === AutomationDesigner Installer ===
echo [1/3] Copying files to %DST% ...
if not exist "%DST%" mkdir "%DST%"
xcopy "%SRC%\*" "%DST%\" /E /Y /Q >nul
echo [2/3] Installing certificate ...
certutil -user -p Build2024! -importpfx My "%DST%\AutomationDesigner_TemporaryKey.pfx" >nul
certutil -user -p Build2024! -importpfx TrustedPublisher "%DST%\AutomationDesigner_TemporaryKey.pfx" >nul
echo [3/3] Registering Excel add-in ...
set "VSTO=%DST:\=/%/AutomationDesigner.vsto"
reg add "HKCU\Software\Microsoft\Office\Excel\Addins\AutomationDesigner" /v Manifest /t REG_SZ /d "file:///%VSTO%|vstolocal" /f >nul
reg add "HKCU\Software\Microsoft\Office\Excel\Addins\AutomationDesigner" /v LoadBehavior /t REG_DWORD /d 3 /f >nul
reg add "HKCU\Software\Microsoft\Office\Excel\Addins\AutomationDesigner" /v FriendlyName /t REG_SZ /d "AutomationDesigner" /f >nul
reg add "HKCU\Software\Microsoft\Office\Excel\Addins\AutomationDesigner" /v Description /t REG_SZ /d "SOLIDWORKS-Excel Automation Add-in" /f >nul
echo.
echo === Installation complete! Now open Excel. ===
pause
